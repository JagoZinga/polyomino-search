TURMITE TESTER - WINDOWS x64

No installation or compiler is required. Extract the whole ZIP first.
Open the extracted turmite-tester folder. Type cmd in File Explorer's address
bar and press Enter. Alternatively double-click Open Command Prompt.cmd.

RUN THE ORIGINAL EXAMPLE AND SAVE ITS PICTURE:
turmite-tester.exe --preset record --steps 100000 --svg record.svg

RUN LANGTON'S ANT AND SAVE ITS PICTURE:
turmite-tester.exe --preset langton --steps 100000 --svg langton.svg

Black cells appear as # in the terminal. ^ > v < marks the ant.
Large terminal views are cropped around the ant. Open the SVG file in a browser
to see the entire pattern. Sample SVG pictures are included in examples.

TEST ALL 65,536 RULES USING FOUR WORKERS, SAVE SCORES AND THE BEST PATTERN:
turmite-tester.exe scan --steps 10000 --threads 4 --csv results.csv --svg best.svg

TEST 2,000 RANDOM RULES WITH A REPEATABLE SEED:
turmite-tester.exe scan --count 2000 --steps 10000 --threads 4 --seed 1 --csv sample.csv

RUN A CANDIDATE FROM THE RANKING (replace 46408 with its rule ID):
turmite-tester.exe --id 46408 --steps 1000000 --svg candidate.svg

DISPLAY ALL COMMANDS:
turmite-tester.exe --help

--seconds N limits wall time; default 0 means no time limit.
--memory-mb N budgets grid tile storage PER WORKER (default64 MB).
--quiet hides terminal drawings/progress. --ascii explicitly draws a terminal view.
--pbm FILE exports a black-cell-only bitmap. --output FILE saves JSON Lines.
Press Ctrl+C to stop; partial simulation statistics are retained.

Rankings use the exact browser heuristic. They do NOT prove predictability or
new records. Incomplete/time-limited/memory-limited rules are never ranked
beside fully evaluated ones. Output files are replaced when names are reused.

The record preset is the example labelled 9.533-trillion-step in the supplied
HTML. Running a short prefix does not verify that claim.
