@echo off
cd /d "%~dp0"
echo Turmite Tester
echo Example: turmite-tester.exe --preset langton --steps 10000 --svg langton.svg
echo Type turmite-tester.exe --help for all commands.
cmd /k
